# Simple Feed Reader

This is a sample application used for [Azure guidance](https://docs.microsoft.com/aspnet/core/azure/?view=aspnetcore-2.1) tutorials.

This app retrieves an RSS feed and displays the results as a list.