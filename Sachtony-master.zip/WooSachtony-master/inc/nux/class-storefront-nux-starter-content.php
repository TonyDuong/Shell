<?php
/**
 * Storefront NUX Starter Content Class
 *
 * @author   WooThemes
 * @package  storefront
 * @since    2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Storefront_NUX_Starter_Content' ) ) :

	/**
	 * The Storefront NUX Starter Content class
	 */
	class Storefront_NUX_Starter_Content {
		/**
		 * Setup class.
		 *
		 * @since 2.2.0
		 */
		public function __construct() {
			add_action( 'after_setup_theme',                    array( $this, 'starter_content' ) );
			add_filter( 'get_theme_starter_content',            array( $this, 'filter_start_content' ), 10, 2 );
			add_action( 'woocommerce_product_query',            array( $this, 'wc_query' ) );
			add_filter( 'woocommerce_shortcode_products_query', array( $this, 'shortcode_loop_products' ), 10, 3 );
			add_action( 'customize_preview_init',               array( $this, 'add_product_tax' ), 10 );
			add_action( 'after_setup_theme',                    array( $this, 'remove_default_widgets' ) );
		}

		/**
		 * Remove default widgets on activation
		 * Set an option so that this is only done the first time the user activates Storefront.
		 *
		 * @since 2.2.0
		 * @return void
		 */
		public function remove_default_widgets() {
			if ( ! get_option( 'storefront_cleared_widgets' ) ) {
				update_option( 'sidebars_widgets', array( 'wp_inactive_widgets' => array() ) );
				update_option( 'storefront_cleared_widgets', true );
			}
		}

		/**
		 * Starter content.
		 *
		 * @since 2.2.0
		 */
		public function starter_content() {
			$starter_content = array(
				'posts' => array(
					'home' => array(
						'post_title'   => esc_attr__( 'Welcome', 'storefront' ),
						'post_content' => sprintf( esc_attr__( 'This is your homepage which is what most visitors will see when they first visit your shop.%sYou can change this text by editing the "Welcome" page via the "Pages" menu in your dashboard.', 'storefront' ), PHP_EOL . PHP_EOL ),
						'template'     => 'template-homepage.php',
						'thumbnail'    => '{{hero-image}}',
					),
					'about' => array(
						'post_type' => 'page',
						'post_title' => _x( 'About', 'Storefront' ),
						'post_content' => _x( 'You might be an artist who would like to introduce yourself and your work here or maybe you&rsquo;re a business with a mission to describe.', 'Storefront' ),
					),
					'contact' => array(
						'post_type' => 'page',
						'post_title' => _x( 'Contact', 'Storefront' ),
						'post_content' => _x( 'This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.', 'Storefront' ),
					),
					'blog'
				),
				'attachments' => array(
					'beanie-image' => array(
						'post_title' => 'Beanie',
						'file'       => 'assets/images/customizer/starter-content/products/beanie.jpg',
					),
					'belt-image' => array(
						'post_title' => 'Belt',
						'file'       => 'assets/images/customizer/starter-content/products/belt.jpg',
					),
					'cap-image' => array(
						'post_title' => 'Cap',
						'file'       => 'assets/images/customizer/starter-content/products/cap.jpg',
					),
					'hoodie-with-logo-image' => array(
						'post_title' => 'Hoodie with Logo',
						'file'       => 'assets/images/customizer/starter-content/products/hoodie-with-logo.jpg',
					),
					'hoodie-with-pocket-image' => array(
						'post_title' => 'Hoodie with Pocket',
						'file'       => 'assets/images/customizer/starter-content/products/hoodie-with-pocket.jpg',
					),
					'hoodie-with-zipper-image' => array(
						'post_title' => 'Hoodie with Zipper',
						'file'       => 'assets/images/customizer/starter-content/products/hoodie-with-zipper.jpg',
					),
					'hoodie-image' => array(
						'post_title' => 'Hoodie',
						'file'       => 'assets/images/customizer/starter-content/products/hoodie.jpg',
					),
					'long-sleeve-tee-image' => array(
						'post_title' => 'Long Sleeve Tee',
						'file'       => 'assets/images/customizer/starter-content/products/long-sleeve-tee.jpg',
					),
					'polo-image' => array(
						'post_title' => 'Polo',
						'file'       => 'assets/images/customizer/starter-content/products/polo.jpg',
					),
					'sunglasses-image' => array(
						'post_title' => 'Sunglasses',
						'file'       => 'assets/images/customizer/starter-content/products/sunglasses.jpg',
					),
					'tshirt-image' => array(
						'post_title' => 'Tshirt',
						'file'       => 'assets/images/customizer/starter-content/products/tshirt.jpg',
					),
					'vneck-tee-image' => array(
						'post_title' => 'Vneck Tshirt',
						'file'       => 'assets/images/customizer/starter-content/products/vneck-tee.jpg',
					),
					'hero-image' => array(
						'post_title' => 'Hero',
						'file'       => 'assets/images/customizer/starter-content/hero.jpg',
					),
					'accessories-image' => array(
						'post_title' => 'Accessories',
						'file'       => 'assets/images/customizer/starter-content/categories/accessories.jpg',
					),
					'tshirts-image' => array(
						'post_title' => 'T-shirts',
						'file'       => 'assets/images/customizer/starter-content/categories/tshirts.jpg',
					),
					'hoodies-image' => array(
						'post_title' => 'Hoodies',
						'file'       => 'assets/images/customizer/starter-content/categories/hoodies.jpg',
					),
				),
				'options' => array(
					'show_on_front'  => 'page',
					'page_on_front'  => '{{home}}',
					'page_for_posts' => '{{blog}}',
				),
				'widgets' => array(
					'footer-1' => array(
						'text_about'
					),
					'footer-2' => array(
						'text_business_info'
					),
				),
				'nav_menus' => array(
					'primary' => array(
						'name' => __( 'Primary Menu', 'storefront' ),
						'items' => array(
							'shop' => array(
								'type'      => 'post_type',
								'object'    => 'page',
								'object_id' => '{{sf_shop}}',
							),
							'page_about' => array(
								'type' => 'post_type',
								'object' => 'page',
								'object_id' => '{{about}}',
							),
							'page_contact' => array(
								'type' => 'post_type',
								'object' => 'page',
								'object_id' => '{{contact}}',
							),
						),
					),
					'secondary' => array(
						'name' => __( 'Secondary Menu', 'storefront' ),
						'items' => array(
							'my_account' => array(
								'type'      => 'post_type',
								'object'    => 'page',
								'object_id' => '{{sf_my-account}}',
							),
						),
					),
					'handheld' => array(
						'name' => __( 'Handheld Menu', 'storefront' ),
						'items' => array(
							'shop' => array(
								'type'      => 'post_type',
								'object'    => 'page',
								'object_id' => '{{sf_shop}}',
							),
						),
					),
				),
			);

			// Add products.
			$starter_content_wc_products = $this->_starter_content_products();

			if ( ! empty( $starter_content_wc_products ) ) {
				$starter_content['posts'] = array_merge( $starter_content['posts'], $starter_content_wc_products );
			}

			// Use symbols as post name for attachments.
			foreach ( $starter_content['attachments'] as $symbol => $attachment ) {
				$starter_content['attachments'][ $symbol ]['post_name'] = $symbol;
			}

			// Add WooCommerce pages.
			$starter_content_wc_pages = array();
			$woocommerce_pages        = Storefront_NUX_Admin::get_woocommerce_pages();

			foreach ( $woocommerce_pages as $option => $page_id ) {
				$page = get_post( $page_id );

				if ( null !== $page ) {
					$starter_content_wc_pages[ 'sf_' . $page->post_name ] = array(
						'post_title' => $page->post_title,
						'post_name'  => $page->post_name,
						'post_type'  => 'page',
					);
				}
			}

			if ( ! empty( $starter_content_wc_pages ) ) {
				$starter_content['posts'] = array_merge( $starter_content['posts'], $starter_content_wc_pages );
			}

			// Register support for starter content.
			add_theme_support( 'starter-content', apply_filters( 'storefront_starter_content', $starter_content ) );
		}

		/**
		 * Filters starter content and remove some of the content if necessary.
		 *
		 * @since 2.2.0
		 * @param array $content Starter content.
		 * @param array $config Config.
		 * @return array $content
		 */
		public function filter_start_content( $content, $config ) {
			if ( ! isset( $_GET['sf_guided_tour'] ) || 1 !== absint( $_GET['sf_guided_tour'] ) ) {
				return $content;
			}

			$tasks = array();

			if ( isset( $_GET['sf_tasks'] ) && '' !== sanitize_text_field( $_GET['sf_tasks'] ) ) {
				$tasks = explode( ',', sanitize_text_field( $_GET['sf_tasks'] ) );
			}

			$tasks = $this->_validate_tasks( $tasks );

			foreach ( $tasks as $task ) {
				switch ( $task ) {
					case 'homepage':
						unset( $content['options'] );

						if ( isset( $content['posts'] ) ) {
							foreach ( $content['posts'] as $post_id => $post ) {
								if ( 'home' === $post_id ) {
									unset( $content['posts'][ $post_id ] );
								}

								if ( 'blog' === $post_id ) {
									unset( $content['posts'][ $post_id ] );
								}
							}
						}

						break;

					case 'products':
						if ( isset( $content['posts'] ) ) {
							foreach ( $content['posts'] as $post_id => $post ) {
								if ( isset( $post['post_type'] ) && 'product' === $post['post_type'] ) {
									unset( $content['posts'][ $post_id ] );
								}
							}
						}

						break;
				}
			}

			// Add custom fields to products.
			$starter_products = $this->_starter_content_products();

			foreach ( $content['posts'] as $post_id => $post ) {
				if ( array_key_exists( $post_id, $starter_products ) && array_key_exists( 'meta_input', $starter_products[ $post_id ] ) ) {
					$content['posts'][ $post_id ]['meta_input'] = $starter_products[ $post_id ]['meta_input'];
				}
			}

			return $content;
		}

		/**
		 * Filter WooCommerce main query to include starter content products.
		 *
		 * @since 2.2.0
		 * @param object $query The Query.
		 * @return void
		 */
		public function wc_query( $query ) {
			if ( ! is_customize_preview() || true !== (bool) get_option( 'fresh_site' ) ) {
				return;
			}

			global $wp_customize;

			$post__in = array();

			// Add existing products.
			$existing_products = $this->_get_existing_wc_products();

			if ( ! empty( $existing_products ) ) {
				$post__in = array_merge( $post__in, $existing_products );
			}

			// Add starter content.
			$data = $wp_customize->get_setting( 'nav_menus_created_posts' );

			if ( ! empty( $data->value() ) ) {

				// Merge starter content products.
				$post__in = array_merge( $post__in, (array) $data->value() );

				// Allow for multiple status.
				$query->set( 'post_status', get_post_stati() );
			}

			// Add products to query.
			$query->set( 'post__in', $post__in );
		}

		/**
		 * Filter shortcode products loop in WooCommerce.
		 *
		 * @since 2.2.0
		 * @param array  $query_args Query args.
		 * @param array  $atts Shortcode attributes.
		 * @param string $loop_name Loop name.
		 * @return array $args
		 */
		public function shortcode_loop_products( $query_args, $atts, $loop_name ) {
			if ( ! is_customize_preview() || true !== (bool) get_option( 'fresh_site' ) ) {
				return $query_args;
			}

			global $wp_customize;

			$query_args['post__in'] = array();

			// Add existing products to query
			$existing_products = $this->_get_existing_wc_products();

			if ( ! empty( $existing_products ) ) {
				$query_args['post__in'] = array_merge( $query_args['post__in'], $existing_products );
			}

			// Add starter content to query
			$data = $wp_customize->get_setting( 'nav_menus_created_posts' );

			if ( ! empty( $data->value() ) ) {

				// Add created products to query.
				$query_args['post__in'] = array_merge( $query_args['post__in'], (array) $data->value() );

				// Allow for multiple status.
				$query_args['post_status'] = get_post_stati();
			}

			return $query_args;
		}

		/**
		 * Add product taxonomies to starter content.
		 *
		 * @since 2.2.0
		 */
		public function add_product_tax() {
			if ( ! is_customize_preview() || true !== (bool) get_option( 'fresh_site' ) ) {
				return;
			}

			global $wp_customize;

			$data = $wp_customize->get_setting( 'nav_menus_created_posts' );

			$created_products = $data->value();

			if ( empty( $created_products ) ) {
				return;
			}

			$starter_products = $this->_starter_content_products();

			if ( is_array( $created_products ) ) {
				foreach ( $created_products as $product ) {
					$product = get_post( $product );

					if ( ! $product ) {
						continue;
					}

					$post_name = get_post_meta( $product->ID, '_customize_draft_post_name', true );

					if ( ! $post_name || ! array_key_exists( $post_name, $starter_products ) ) {
						continue;
					}

					$taxonomies = array( 'product_cat', 'product_tag' );

					foreach ( $taxonomies as $taxonomy ) {
						if ( array_key_exists( $taxonomy, $starter_products[ $post_name ]['taxonomy'] ) ) {
							$categories = $starter_products[ $post_name ]['taxonomy'][ $taxonomy ];

							if ( ! empty( $categories ) ) {
								$category_ids = array();

								foreach ( $categories as $category ) {
									// Check if the term already exists.
									$category_exists = term_exists( $category['term'], $taxonomy );

									if ( $category_exists ) {
										$category_ids[] = (int) $category_exists['term_id'];

										continue;
									}

									// Create new category.
									$created_category = wp_insert_term(
										$category['term'],
										$taxonomy,
										array(
											'description' => $category['description'],
											'slug'        => $category['slug'],
										)
									);

									if ( ! is_wp_error( $created_category ) ) {
										$category_ids[] = $created_category['term_id'];

										$category_image = $this->_get_category_image_attachment_id( $category['slug'] );

										if ( $category_image ) {
											update_term_meta( (int) $created_category['term_id'], 'thumbnail_id', $category_image );
										}
									}
								}

								wp_set_object_terms( $product->ID, $category_ids, $taxonomy );
							}
						}
					}
				}
			}

			add_filter( 'storefront_product_categories_shortcode_args', array( $this, 'filter_sf_categories' ) );
		}

		/**
		 * Filter Storefront Product Categories shortcode.
		 *
		 * @since 2.2.0
		 * @param array $args Shortcode args.
		 * @return array $args
		 */
		public function filter_sf_categories( $args ) {
			// Get Categories.
			$product_cats = get_terms( 'product_cat', array( 'fields' => 'ids', 'hide_empty' => false ) );

			if ( ! empty( $product_cats ) ) {

				// Needs to be set for categories to show up.
				$args['hide_empty'] = false;

				// List of categories to display.
				$args['ids'] = implode( $product_cats, ',' );
			}

			return $args;
		}

		/**
		 * Starter content products.
		 *
		 * @since 2.2.0
		 */
		private function _starter_content_products() {
			$accessories_name        = esc_attr__( 'Accessories', 'storefront' );
			$accessories_description = esc_attr__( 'A short category description', 'storefront' );

			$hoodies_name            = esc_attr__( 'Hoodies', 'storefront' );
			$hoodies_description     = esc_attr__( 'A short category description', 'storefront' );

			$tshirts_name            = esc_attr__( 'Tshirts', 'storefront' );
			$tshirts_description     = esc_attr__( 'A short category description', 'storefront' );

			$products = array(
				// Accessories
				'beanie' => array(
					'post_title'     => esc_attr__( 'Beanie', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{beanie-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '20',
						'_price'             => '18',
						'_sale_price'        => '18',
						'_featured'          => 'no',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $accessories_name,
								'slug'        => 'accessories',
								'description' => $accessories_description,
							),
						),
					),

				),
				'belt' => array(
					'post_title'     => esc_attr__( 'Belt', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{belt-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '65',
						'_price'             => '55',
						'_sale_price'        => '55',
						'_featured'          => 'no',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $accessories_name,
								'slug'        => 'accessories',
								'description' => $accessories_description,
							),
						),
					),
				),
				'cap' => array(
					'post_title'     => esc_attr__( 'Cap', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{cap-image}}',
					'meta_input'   => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '18',
						'_price'             => '16',
						'_sale_price'        => '16',
						'_featured'          => 'no',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $accessories_name,
								'slug'        => 'accessories',
								'description' => $accessories_description,
							),
						),
					),
				),
				'sunglasses' => array(
					'post_title'     => esc_attr__( 'Sunglasses', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{sunglasses-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '90',
						'_price'             => '90',
						'_featured'          => 'yes',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $accessories_name,
								'slug'        => 'accessories',
								'description' => $accessories_description,
							),
						),
					),
				),
				'hoodie-with-logo' => array(
					'post_title'     => esc_attr__( 'Hoodie with Logo', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{hoodie-with-logo-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '45',
						'_price'             => '45',
						'_featured'          => 'no',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $hoodies_name,
								'slug'        => 'hoodies',
								'description' => $hoodies_description,
							),
						),
					),
				),
				'hoodie-with-pocket' => array(
					'post_title'     => esc_attr__( 'Hoodie with Pocket', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{hoodie-with-pocket-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '45',
						'_price'             => '35',
						'_sale_price'        => '35',
						'_featured'          => 'no',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $hoodies_name,
								'slug'        => 'hoodies',
								'description' => $hoodies_description,
							),
						),
					),
				),
				'hoodie-with-zipper' => array(
					'post_title'     => esc_attr__( 'Hoodie with Zipper', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{hoodie-with-zipper-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '45',
						'_price'             => '45',
						'_featured'          => 'yes',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $hoodies_name,
								'slug'        => 'hoodies',
								'description' => $hoodies_description,
							),
						),
					),
				),
				'hoodie' => array(
					'post_title'   => esc_attr__( 'Hoodie', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{hoodie-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '45',
						'_price'             => '42',
						'_sale_price'        => '42',
						'_featured'          => 'yes',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $hoodies_name,
								'slug'        => 'hoodies',
								'description' => $hoodies_description,
							),
						),
					),
				),
				'long-sleeve-tee' => array(
					'post_title'     => esc_attr__( 'Long Sleeve Tee', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{long-sleeve-tee-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '25',
						'_price'             => '25',
						'_featured'          => 'no',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $tshirts_name,
								'slug'        => 'tshirts',
								'description' => $tshirts_description,
							),
						),
					),
				),
				'polo' => array(
					'post_title'     => esc_attr__( 'Polo', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{polo-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '20',
						'_price'             => '20',
						'_featured'          => 'no',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $tshirts_name,
								'slug'        => 'tshirts',
								'description' => $tshirts_description,
							),
						),
					),
				),
				'tshirt' => array(
					'post_title'     => esc_attr__( 'Tshirt', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{tshirt-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '18',
						'_price'             => '18',
						'_featured'          => 'no',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $tshirts_name,
								'slug'        => 'tshirts',
								'description' => $tshirts_description,
							),
						),
					),
				),
				'vneck-tee' => array(
					'post_title'     => esc_attr__( 'Vneck Tshirt', 'storefront' ),
					'post_content'   => 'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo.',
					'post_type'      => 'product',
					'comment_status' => 'open',
					'thumbnail'      => '{{vneck-tee-image}}',
					'meta_input'     => array(
						'_visibility'        => 'visible',
						'_regular_price'     => '18',
						'_price'             => '18',
						'_featured'          => 'yes',
					),
					'taxonomy' => array(
						'product_cat' => array(
							array(
								'term'        => $tshirts_name,
								'slug'        => 'tshirts',
								'description' => $tshirts_description,
							),
						),
					),
				),
			);

			// Use symbols as post name.
			foreach ( $products as $symbol => $product ) {
				$products[ $symbol ]['post_name'] = $symbol;
			}

			return apply_filters( 'storefront_starter_content_products', $products );
		}

		/**
		 * Get a list of existing products in the store.
		 *
		 * @since 2.2.0
		 * @return array $query Array of product ids.
		 */
		private function _get_existing_wc_products() {
			$query_args = array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'fields'         => 'ids',
				'posts_per_page' => -1,
			);

			$products = get_posts( $query_args );

			if ( $products && ! empty( $products ) ) {
				return $products;
			}

			return array();
		}

		/**
		 * Given a category slug, find the related image attachment.
		 *
		 * @since 2.2.0
		 * @param string $category Category.
		 * @return mixed false|int $query first attachment found.
		 */
		private function _get_category_image_attachment_id( $category ) {
			$query_args = array(
				'post_type'      => 'attachment',
				'post_status'    => 'auto-draft',
				'fields'         => 'ids',
				'posts_per_page' => -1,
				'meta_query'     => array(
					array(
						'key'     => '_customize_draft_post_name',
						'value'   => $category . '-image',
						'compare' => '=',
					),
				),
			);

			$query = get_posts( $query_args );

			if ( $query && ! empty( $query ) ) {
				return $query[0];
			}

			return false;
		}

		/**
		 * Validates and sanitizes a given tasks list.
		 *
		 * @since 2.2.0
		 * @param string $tasks The tasks.
		 * @return mixed false|array $validated_tasks if tasks list is not empty.
		 */
		private function _validate_tasks( $tasks ) {
			$valid_tasks = apply_filters( 'storefront_valid_tour_tasks', array( 'homepage', 'products' ) );

			$validated_tasks = array();

			foreach ( $tasks as $task ) {
				$task = sanitize_key( $task );

				if ( in_array( $task, $valid_tasks, true ) ) {
					$validated_tasks[] = $task;
				}
			}

			$validated_tasks = array_diff( $valid_tasks, $validated_tasks );

			return $validated_tasks;
		}
	}

endif;

return new Storefront_NUX_Starter_Content();
